"""
AI Tutor — Self-Learning RAG System
Streamlit deployment of the original Colab notebook.

Supports two backends, switchable in the sidebar:
  - Local  : Qwen2.5-1.5B-Instruct + SentenceTransformer + FAISS (no API key)
  - Groq   : llama-3.3-70b-versatile via Groq API (needs GROQ_API_KEY)

Bug fixed from the notebook: the correct reference answer is now ALWAYS
shown to the student after evaluation (for both MCQ and open-ended
questions), instead of being buried inside (or missing from) free-text
LLM feedback.
"""

import os
import re
import json
import random
import pathlib
import tempfile
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any

import numpy as np
import streamlit as st

# ──────────────────────────────────────────────────────────────────────────
# Page config
# ──────────────────────────────────────────────────────────────────────────
st.set_page_config(page_title="AI Tutor", page_icon="🎓", layout="wide")

# ──────────────────────────────────────────────────────────────────────────
# Sidebar — backend selection & config
# ──────────────────────────────────────────────────────────────────────────
st.sidebar.title("🎓 AI Tutor — Settings")

BACKEND = st.sidebar.radio(
    "Answer / Question / Eval engine",
    ["Groq API (fast, needs API key)", "Local models (slower, no API key)"],
    index=0,
)
USE_GROQ = BACKEND.startswith("Groq")

if USE_GROQ:
    groq_key_input = st.sidebar.text_input(
        "GROQ_API_KEY",
        value=os.environ.get("GROQ_API_KEY", ""),
        type="password",
        help="Get a free key at https://console.groq.com/keys. "
             "Never share or commit this key.",
    )
    if groq_key_input:
        os.environ["GROQ_API_KEY"] = groq_key_input

st.sidebar.markdown("---")
n_open = st.sidebar.slider("Open-ended questions", 0, 8, 3)
n_mcq = st.sidebar.slider("MCQ questions", 0, 8, 2)
top_k = st.sidebar.slider("Retrieval top-k", 2, 10, 5)

st.sidebar.markdown("---")
st.sidebar.caption(
    "⚠️ Security note: the original notebook had a Groq API key and a "
    "LangSmith key hardcoded in plaintext in a cell. Those should be "
    "revoked immediately if not already. This app reads the key only "
    "from the field above or the GROQ_API_KEY environment variable — "
    "it is never stored in code."
)

# ──────────────────────────────────────────────────────────────────────────
# Lazy / cached resource loaders
# ──────────────────────────────────────────────────────────────────────────

@st.cache_resource(show_spinner=False)
def get_embedding_model():
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")


@st.cache_resource(show_spinner=False)
def get_local_qa_pipe():
    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
    model_name = "Qwen/Qwen2.5-1.5B-Instruct"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=torch.float16 if device == "cuda" else torch.float32,
        device_map="auto",
    )
    return pipeline("text-generation", model=model, tokenizer=tokenizer, max_new_tokens=256)


@st.cache_resource(show_spinner=False)
def get_groq_client():
    from groq import Groq
    api_key = os.environ.get("GROQ_API_KEY", "")
    if not api_key:
        return None
    return Groq(api_key=api_key)


def llm_generate(prompt: str, max_tokens: int = 256, system: str = "You are an educational AI tutor.") -> str:
    """
    Unified text-generation call across both backends.
    Returns ONLY the newly generated text (prompt is stripped for local models —
    this fixes a bug in the original notebook where the local pipeline's
    output included the echoed prompt).
    """
    if USE_GROQ:
        client = get_groq_client()
        if client is None:
            raise RuntimeError("Groq API key not set. Enter it in the sidebar.")
        resp = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
            temperature=0.3,
            max_tokens=max_tokens,
        )
        return resp.choices[0].message.content.strip()
    else:
        pipe = get_local_qa_pipe()
        out = pipe(prompt, max_new_tokens=max_tokens, do_sample=False)
        full_text = out[0]["generated_text"]
        # FIX: text-generation pipelines echo the prompt back; strip it.
        if full_text.startswith(prompt):
            return full_text[len(prompt):].strip()
        return full_text.strip()


# ──────────────────────────────────────────────────────────────────────────
# Document loading (multi-format) — ported from notebook Cell 3
# ──────────────────────────────────────────────────────────────────────────

def clean_text(text: str) -> str:
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\n{2,}", "\n", text)
    text = text.replace("\x00", " ")
    return text.strip()


def get_tesseract():
    try:
        import pytesseract
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "Please install pytesseract."
        ) from exc

    # Tell pytesseract exactly where Tesseract is
    pytesseract.pytesseract.tesseract_cmd = (
        r"C:\Program Files\Tesseract-OCR\tesseract.exe"
    )

    try:
        pytesseract.get_tesseract_version()
    except Exception as exc:
        raise RuntimeError(
            f"Unable to execute Tesseract: {exc}"
        ) from exc

    return pytesseract

def load_pdf(path: str) -> str:
    import fitz  # PyMuPDF
    from PIL import Image
    pytesseract = get_tesseract()
    doc = fitz.open(path)
    texts = []
    for page in doc:
        text = page.get_text("text")
        if len(text.strip()) < 50:
            pix = page.get_pixmap(dpi=150)
            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            texts.append(pytesseract.image_to_string(img))
        else:
            texts.append(text)
    return clean_text("\n".join(texts))


def load_docx(path: str) -> str:
    from docx import Document as DocxDocument
    doc = DocxDocument(path)
    parts = [p.text for p in doc.paragraphs if p.text.strip()]
    for table in doc.tables:
        for row in table.rows:
            parts.append(" | ".join(c.text for c in row.cells))
    return clean_text("\n".join(parts))


def load_txt(path: str) -> str:
    return clean_text(pathlib.Path(path).read_text(encoding="utf-8", errors="replace"))


def load_csv_excel(path: str) -> str:
    import pandas as pd
    ext = pathlib.Path(path).suffix.lower()
    df = pd.read_csv(path) if ext == ".csv" else pd.read_excel(path)
    lines = [
        f"Dataset contains {df.shape[0]} rows and {df.shape[1]} columns.",
        f"Columns: {', '.join(df.columns.astype(str))}",
    ]
    missing = df.isnull().sum()
    missing = missing[missing > 0]
    if len(missing) > 0:
        lines.append("\nMissing Values:\n" + missing.to_string())
    num_cols = df.select_dtypes(include=np.number).columns
    if len(num_cols) > 0:
        lines.append("\nNumeric Statistics:\n" + df[num_cols].describe().to_string())
    lines.append("\nSample Records:\n" + df.head(10).to_string(index=False))
    return clean_text("\n".join(lines))


def load_image(path: str) -> str:
    from PIL import Image
    pytesseract = get_tesseract()
    return clean_text(pytesseract.image_to_string(Image.open(path)))


LOADERS = {
    ".pdf": load_pdf, ".docx": load_docx, ".txt": load_txt, ".md": load_txt,
    ".csv": load_csv_excel, ".xlsx": load_csv_excel, ".xls": load_csv_excel,
    ".png": load_image, ".jpg": load_image, ".jpeg": load_image,
}


def load_document(path: str) -> str:
    ext = pathlib.Path(path).suffix.lower()
    loader = LOADERS.get(ext)
    if loader is None:
        raise ValueError(f"Unsupported file type: {ext}")
    return loader(path)


# ──────────────────────────────────────────────────────────────────────────
# Chunking + retrieval (FAISS) — ported from notebook Cell 4
# ──────────────────────────────────────────────────────────────────────────

@dataclass
class Chunk:
    text: str
    chunk_id: int


def split_text(text: str, chunk_size: int = 1200, overlap: int = 200) -> List[str]:
    """Simple recursive-ish splitter (mirrors LangChain's RecursiveCharacterTextSplitter behavior)."""
    separators = ["\n\n", "\n", ". ", "! ", "? ", "; ", " "]

    def _split(t: str, seps: List[str]) -> List[str]:
        if len(t) <= chunk_size:
            return [t] if t.strip() else []
        if not seps:
            return [t[i:i + chunk_size] for i in range(0, len(t), chunk_size - overlap)]
        sep = seps[0]
        parts = t.split(sep)
        chunks, current = [], ""
        for part in parts:
            candidate = current + sep + part if current else part
            if len(candidate) <= chunk_size:
                current = candidate
            else:
                if current:
                    chunks.append(current)
                current = part
        if current:
            chunks.append(current)
        result = []
        for c in chunks:
            if len(c) > chunk_size:
                result.extend(_split(c, seps[1:]))
            else:
                result.append(c)
        return result

    raw = _split(text, separators)
    # de-dup
    seen, unique = set(), []
    for c in raw:
        c = c.strip()
        if c and c not in seen:
            seen.add(c)
            unique.append(c)
    return unique


class VectorStore:
    """Thin FAISS wrapper (numpy-based cosine search; avoids extra langchain dependency surface)."""

    def __init__(self):
        self.chunks: List[Chunk] = []
        self.embeddings: Optional[np.ndarray] = None
        self.embedder = get_embedding_model()

    def build(self, text: str):
        raw_chunks = split_text(text)
        self.chunks = [Chunk(text=c, chunk_id=i) for i, c in enumerate(raw_chunks)]
        vecs = self.embedder.encode(
            [c.text for c in self.chunks], normalize_embeddings=True, batch_size=32,
            show_progress_bar=False,
        )
        self.embeddings = np.array(vecs, dtype=np.float32)

    def retrieve(self, query: str, k: int = 5) -> List[Chunk]:
        if self.embeddings is None or len(self.chunks) == 0:
            return []
        q_vec = self.embedder.encode([query], normalize_embeddings=True, show_progress_bar=False)[0]
        sims = self.embeddings @ q_vec
        top_idx = np.argsort(-sims)[:k]
        return [self.chunks[i] for i in top_idx if len(self.chunks[i].text.strip()) > 50]


def build_context(chunks: List[Chunk]) -> str:
    return "\n\n".join(c.text for c in chunks)


# ──────────────────────────────────────────────────────────────────────────
# RAG QA
# ──────────────────────────────────────────────────────────────────────────

def rag_answer(query: str, vs: VectorStore, k: int) -> Dict[str, Any]:
    docs = vs.retrieve(query, k=k)
    context = build_context(docs)
    prompt = (
        "Answer the question based on the context below. "
        "If the answer is a number or formula, include it exactly.\n\n"
        f"Context:\n{context[:1500]}\n\n"
        f"Question: {query}\n\nAnswer:"
    )
    answer = llm_generate(prompt, max_tokens=300)
    return {"answer": answer, "context": context, "n_sources": len(docs)}


# ──────────────────────────────────────────────────────────────────────────
# Question generation — ported & simplified from notebook Cells 7 / 41 / 43
# ──────────────────────────────────────────────────────────────────────────

@dataclass
class Question:
    qtype: str                 # 'open' | 'mcq'
    text: str
    options: List[str] = field(default_factory=list)
    correct_answer: str = ""
    context_chunk: str = ""
    difficulty: str = "medium"


def is_good_question(q: str) -> bool:
    q = q.strip()
    if len(q) < 15 or len(q.split()) < 4:
        return False
    bad = ["according to the context", "what is mentioned", "question:", "answer:"]
    if any(p in q.lower() for p in bad):
        return False
    return q.endswith("?")


def generate_open_questions(chunks: List[Chunk], n: int) -> List[Question]:
    questions = []
    pool = random.sample(chunks, min(n * 4, len(chunks))) if chunks else []
    for ch in pool:
        if len(questions) >= n:
            break
        ctx = ch.text[:600]
        prompt = (
            "You are an expert educator. Generate ONE meaningful conceptual "
            "question from the context below.\n\n"
            "STRICT RULES:\n- Ask ONLY from the context\n- Do NOT reveal the answer\n"
            "- Avoid copying sentences directly\n- Output ONLY the question\n\n"
            f"Context:\n{ctx}\n\nQuestion:"
        )
        try:
            q_text = llm_generate(prompt, max_tokens=64).replace("Question:", "").strip()
            q_text = q_text.replace("\n", " ")
            if not q_text.endswith("?"):
                q_text += "?"
            if not is_good_question(q_text):
                continue
            ref_prompt = f"Answer briefly from the context.\n\nContext:\n{ctx}\n\nQuestion:\n{q_text}\n\nAnswer:"
            ref = llm_generate(ref_prompt, max_tokens=100).strip()
            questions.append(Question(
                qtype="open", text=q_text, correct_answer=ref, context_chunk=ctx,
                difficulty=random.choice(["easy", "medium", "hard"]),
            ))
        except Exception as e:
            st.warning(f"Open question generation skipped one chunk: {e}")
            continue
    return questions


def generate_mcq_questions(chunks: List[Chunk], n: int) -> List[Question]:
    questions = []
    pool = random.sample(chunks, min(n * 3, len(chunks))) if chunks else []
    for ch in pool:
        if len(questions) >= n:
            break
        ctx = ch.text[:700]
        prompt = (
            "You are an expert assessment generator. Create ONE high-quality "
            "multiple choice question with 4 options. Avoid 'All/None of the above'. "
            "Output ONLY valid JSON in this exact format:\n"
            '{"question":"...","options":["A. ...","B. ...","C. ...","D. ..."],"correct":"A"}\n\n'
            f"Context:\n{ctx}"
        )
        try:
            response = llm_generate(prompt, max_tokens=300)
            match = re.search(r"\{[\s\S]*\}", response)
            if not match:
                continue
            data = json.loads(match.group())
            if "question" not in data or "options" not in data or len(data["options"]) != 4:
                continue
            unique_options = list(dict.fromkeys(data["options"]))
            if len(unique_options) < 4:
                continue
            correct_letter = data.get("correct", "A").strip().upper()
            correct_option = next(
                (o for o in unique_options if o.strip().upper().startswith(correct_letter)),
                unique_options[0],
            )
            questions.append(Question(
                qtype="mcq", text=data["question"], options=unique_options,
                correct_answer=correct_option, context_chunk=ctx,
                difficulty=random.choice(["easy", "medium", "hard"]),
            ))
        except Exception as e:
            st.warning(f"MCQ generation skipped one chunk: {e}")
            continue
    return questions


# ──────────────────────────────────────────────────────────────────────────
# Evaluation — ported from notebook Cell 8, WITH THE BUG FIXED:
# correct_answer is now always returned and always rendered in the UI.
# ──────────────────────────────────────────────────────────────────────────

@dataclass
class EvalResult:
    semantic_score: float
    keyword_score: float
    combined: float
    correct: bool
    feedback: str
    missed_keywords: List[str]
    confidence: float = 0.0


SEM_WEIGHT, KW_WEIGHT = 0.6, 0.4
DIFFICULTY_THRESHOLDS = {"easy": 0.40, "medium": 0.58, "hard": 0.70}

_STOPWORDS = {
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being", "of", "to",
    "in", "on", "at", "for", "with", "as", "by", "this", "that", "it", "and", "or",
    "but", "if", "from", "into", "than", "then", "so", "such", "not", "no", "do",
    "does", "did", "has", "have", "had", "will", "would", "can", "could", "should",
}


def keyword_overlap(reference: str, hypothesis: str):
    ref_tok = {t.lower() for t in re.findall(r"[A-Za-z]+", reference) if t.lower() not in _STOPWORDS}
    hyp_tok = {t.lower() for t in re.findall(r"[A-Za-z]+", hypothesis) if t.lower() not in _STOPWORDS}
    if not ref_tok:
        return 1.0, []
    hit = ref_tok & hyp_tok
    return len(hit) / len(ref_tok), list(ref_tok - hyp_tok)


def cosine_sim(a: np.ndarray, b: np.ndarray) -> float:
    denom = (np.linalg.norm(a) * np.linalg.norm(b))
    return float(np.dot(a, b) / denom) if denom else 0.0


def generate_feedback(question: str, reference: str, user_answer: str, score: float,
                       missed: List[str], difficulty: str) -> str:
    grade = ("Excellent" if score >= 0.80 else "Good" if score >= 0.65
             else "Partial" if score >= 0.45 else "Needs work")
    missed_text = ", ".join(missed[:6]) if missed else "None"
    prompt = (
        "You are a precise, encouraging AI tutor grading a student's answer.\n\n"
        f"Question      : {question}\n"
        f"Reference     : {reference}\n"
        f"Student answer: {user_answer}\n"
        f"Score         : {score:.2f}/1.00 ({grade})\n"
        f"Difficulty    : {difficulty}\n"
        f"Missing terms : {missed_text}\n\n"
        "Write a short tutor response (3-5 sentences): what they got right, "
        "the key gap, and one concrete improvement tip. Positive, educational tone, no bullet points."
    )
    try:
        return llm_generate(prompt, max_tokens=180)
    except Exception:
        return f"Score: {score:.0%}. Missing concepts: {missed_text}."


def evaluate_answer(question: Question, user_answer: str) -> EvalResult:
    ref = question.correct_answer.strip()
    user_answer = user_answer.strip()
    difficulty = question.difficulty

    if question.qtype == "mcq":
        user_clean = user_answer.strip().lower()
        correct_letter = question.correct_answer.strip().lower()[0:1]
        is_correct = (user_clean == correct_letter) or (user_clean in question.correct_answer.lower())
        score = 1.0 if is_correct else 0.0
        # FIX: always state the correct answer explicitly, not just on wrong answers,
        # so the UI has one consistent field to render.
        feedback = "Correct! Well done." if is_correct else "Incorrect — see the correct answer below."
        return EvalResult(score, score, score, is_correct, feedback, [], score)

    if len(user_answer.split()) < 2:
        return EvalResult(0.0, 0.0, 0.0, False, "Answer too short — please elaborate.", [], 0.0)

    embedder = get_embedding_model()
    emb = embedder.encode([ref, user_answer], normalize_embeddings=True, show_progress_bar=False)
    semantic_score = cosine_sim(emb[0], emb[1])
    keyword_score, missed = keyword_overlap(ref, user_answer)
    combined = round(SEM_WEIGHT * semantic_score + KW_WEIGHT * keyword_score, 4)
    agreement_penalty = abs(semantic_score - keyword_score)
    confidence = round(max(0.0, combined - 0.15 * agreement_penalty), 4)
    threshold = DIFFICULTY_THRESHOLDS.get(difficulty, 0.58)
    is_correct = combined >= threshold

    feedback = generate_feedback(question.text, ref, user_answer, combined, missed, difficulty)

    return EvalResult(
        semantic_score=round(semantic_score, 4), keyword_score=round(keyword_score, 4),
        combined=combined, correct=is_correct, feedback=feedback,
        missed_keywords=missed[:5], confidence=confidence,
    )


# ──────────────────────────────────────────────────────────────────────────
# Session state init
# ──────────────────────────────────────────────────────────────────────────

def init_session():
    defaults = {
        "vs": None, "doc_loaded": False, "doc_name": "",
        "questions": [], "current_idx": 0, "answers": [], "evals": [],
        "quiz_active": False, "quiz_finished": False,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v


init_session()

# ──────────────────────────────────────────────────────────────────────────
# UI — Header
# ──────────────────────────────────────────────────────────────────────────

st.title("🎓 AI Tutor — Self-Learning RAG System")
st.caption(f" **{'' if USE_GROQ else 'Local (Qwen2.5-1.5B)'}**")

tab_upload, tab_ask, tab_quiz, tab_report = st.tabs(
    ["📂 Upload Document", "💬 Ask Questions", "📝 Take Quiz", "📊 Report"]
)

# ──────────────────────────────────────────────────────────────────────────
# Tab 1 — Upload
# ──────────────────────────────────────────────────────────────────────────
with tab_upload:
    st.subheader("Upload a document to learn from")
    uploaded = st.file_uploader(
        "Supported: PDF, DOCX, TXT, MD, CSV, XLSX, PNG, JPG",
        type=["pdf", "docx", "txt", "md", "csv", "xlsx", "xls", "png", "jpg", "jpeg"],
    )
    if uploaded is not None:
        if st.button("📥 Index this document", type="primary"):
            with st.spinner("Loading and indexing document — this may take a minute..."):
                suffix = pathlib.Path(uploaded.name).suffix
                with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                    tmp.write(uploaded.getvalue())
                    tmp_path = tmp.name
                try:
                    text = load_document(tmp_path)
                    vs = VectorStore()
                    vs.build(text)
                    st.session_state.vs = vs
                    st.session_state.doc_loaded = True
                    st.session_state.doc_name = uploaded.name
                    st.session_state.questions = []
                    st.session_state.answers = []
                    st.session_state.evals = []
                    st.session_state.quiz_active = False
                    st.session_state.quiz_finished = False
                    st.success(f"✅ Indexed **{uploaded.name}** — {len(vs.chunks)} chunks, {len(text):,} characters.")
                except Exception as e:
                    st.error(f"Failed to load document: {e}")
                finally:
                    os.unlink(tmp_path)

    if st.session_state.doc_loaded:
        st.info(f"📄 Currently loaded: **{st.session_state.doc_name}** "
                f"({len(st.session_state.vs.chunks)} chunks)")

# ──────────────────────────────────────────────────────────────────────────
# Tab 2 — Ask (RAG QA)
# ──────────────────────────────────────────────────────────────────────────
with tab_ask:
    st.subheader("Ask anything about the document")
    if not st.session_state.doc_loaded:
        st.warning("Upload and index a document first.")
    else:
        query = st.text_input("Your question", placeholder="e.g. What is the formula for...")
        if st.button("Ask", type="primary") and query.strip():
            with st.spinner("Thinking..."):
                try:
                    result = rag_answer(query, st.session_state.vs, k=top_k)
                    st.markdown("### Answer")
                    st.write(result["answer"])
                    with st.expander(f"Sources used ({result['n_sources']} chunks)"):
                        st.text(result["context"][:2000])
                except Exception as e:
                    st.error(f"Error: {e}")

# ──────────────────────────────────────────────────────────────────────────
# Tab 3 — Quiz
# ──────────────────────────────────────────────────────────────────────────
with tab_quiz:
    st.subheader("Take a quiz on the document")
    if not st.session_state.doc_loaded:
        st.warning("Upload and index a document first.")
    else:
        if not st.session_state.quiz_active and not st.session_state.quiz_finished:
            if st.button("🚀 Generate Quiz", type="primary"):
                with st.spinner(f"Generating {n_open} open + {n_mcq} MCQ questions..."):
                    chunks = st.session_state.vs.chunks
                    questions = generate_open_questions(chunks, n_open) + generate_mcq_questions(chunks, n_mcq)
                    random.shuffle(questions)
                    if not questions:
                        st.error("Could not generate any questions — try a longer document or fewer questions.")
                    else:
                        st.session_state.questions = questions
                        st.session_state.current_idx = 0
                        st.session_state.answers = []
                        st.session_state.evals = []
                        st.session_state.quiz_active = True
                        st.session_state.quiz_finished = False
                        st.rerun()

        elif st.session_state.quiz_active:
            qs = st.session_state.questions
            idx = st.session_state.current_idx

            if idx >= len(qs):
                st.session_state.quiz_active = False
                st.session_state.quiz_finished = True
                st.rerun()
            else:
                q = qs[idx]
                badge = {"easy": "🟢 EASY", "medium": "🟡 MEDIUM", "hard": "🔴 HARD"}.get(q.difficulty, q.difficulty)
                st.markdown(f"**Question {idx + 1}/{len(qs)}**  ·  {badge}  ·  {q.qtype.upper()}")
                st.markdown(f"### {q.text}")

                with st.form(key=f"q_form_{idx}"):
                    if q.qtype == "mcq":
                        for opt in q.options:
                            st.write(opt)
                        user_answer = st.radio(
                            "Your answer", options=["A", "B", "C", "D"], horizontal=True,
                            key=f"radio_{idx}",
                        )
                    else:
                        user_answer = st.text_area("Your answer", key=f"text_{idx}", height=120)

                    submitted = st.form_submit_button("Submit Answer", type="primary")

                    if submitted:
                        ua = (user_answer or "").strip() or "No answer"
                        result = evaluate_answer(q, ua)
                        st.session_state.answers.append(ua)
                        st.session_state.evals.append(result)
                        st.session_state.current_idx += 1
                        st.rerun()

        elif st.session_state.quiz_finished:
            st.success("Quiz complete! See the **Report** tab for your results.")
            if st.button("🔁 Start a new quiz"):
                st.session_state.quiz_active = False
                st.session_state.quiz_finished = False
                st.session_state.questions = []
                st.session_state.answers = []
                st.session_state.evals = []
                st.rerun()

# ──────────────────────────────────────────────────────────────────────────
# Tab 4 — Report
# ──────────────────────────────────────────────────────────────────────────
with tab_report:
    st.subheader("Session Report")
    qs = st.session_state.questions
    evals = st.session_state.evals
    answers = st.session_state.answers

    if not evals:
        st.info("No quiz answers yet. Complete a quiz to see your report.")
    else:
        total = len(evals)
        correct = sum(1 for r in evals if r.correct)
        avg_score = float(np.mean([r.combined for r in evals])) * 100

        col1, col2, col3 = st.columns(3)
        col1.metric("Correct", f"{correct}/{total}")
        col2.metric("Average Score", f"{avg_score:.1f}%")
        col3.metric("Questions Answered", total)

        st.markdown("---")
        st.markdown("### Question-by-question breakdown")

        for i, (q, ua, r) in enumerate(zip(qs, answers, evals)):
            status = "✅" if r.correct else "❌"
            with st.expander(f"{status} Q{i+1} [{q.qtype.upper()}] — Score: {r.combined:.0%} — {q.text[:70]}"):
                st.markdown(f"**Question:** {q.text}")
                if q.qtype == "mcq":
                    for opt in q.options:
                        st.write(opt)
                st.markdown(f"**Your answer:** {ua}")
                # ── BUG FIX: always render the correct answer explicitly ──
                st.markdown(f"**✔️ Correct answer:** {q.correct_answer}")
                st.markdown(f"**Feedback:** {r.feedback}")
                if q.qtype == "open":
                    st.caption(
                        f"Semantic similarity: {r.semantic_score:.0%} · "
                        f"Keyword overlap: {r.keyword_score:.0%} · "
                        f"Confidence: {r.confidence:.0%}"
                    )
                    if r.missed_keywords:
                        st.caption(f"Missed key terms: {', '.join(r.missed_keywords)}")

        weak = [q.text[:60] for q, r in zip(qs, evals) if not r.correct]
        if weak:
            st.markdown("### 📌 Topics to revise")
            for w in weak:
                st.write(f"- {w}")
