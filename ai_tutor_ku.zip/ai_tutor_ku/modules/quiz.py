
from typing import Optional
import pathlib

from rich.console import Console
from rich.panel import Panel

from modules.vector_store import VectorStoreManager
from modules.doc_loader import load_document
from modules.langraph import tutor_graph, TutorState
from modules.eval import evaluate_answer, mastery_tracker

console = Console()

import ipywidgets as widgets
from IPython.display import display, clear_output
_quiz_state = None
_quiz_out   = None

def _start_quiz_callback(state):
    global _quiz_state, _quiz_out
    questions = state['questions']
    if not questions:
        console.print("[red]❌ No questions generated.[/red]")
        return
    _quiz_state = {
        'questions':   questions,
        'answers':     [],
        'evals':       [],
        'history':     state.get('history', []),
        'current_idx': 0,
        'state_ref':   state,
    }
    _quiz_out = widgets.Output()
    display(_quiz_out)
    _show_next_question()

def _show_next_question():
    global _quiz_state, _quiz_out
    qs = _quiz_state
    if qs['current_idx'] >= len(qs['questions']):
        _finish_quiz()
        return
    q = qs['questions'][qs['current_idx']]
    i = qs['current_idx']

    with _quiz_out:
        clear_output(wait=True)
        # Show per-question difficulty badge
        badge = {"easy": "🟢 EASY", "medium": "🟡 MEDIUM", "hard": "🔴 HARD"}.get(
            q.difficulty, q.difficulty.upper())
        console.rule(f"[bold cyan]Question {i+1}/{len(qs['questions'])}[/bold cyan]"
                     f"  [{badge}]  Topic: {q.topic_hint or '—'}")
        if q.qtype == "mcq":
            print(f"\n{q.text}\n")
            for opt in q.options: print(opt)
            print("\n( Type your answer: A, B, C, or D )")
        else:
            print(f"\n{q.text}\n( Type your answer )\n")

    answer_widget = widgets.Text(
        placeholder="Write your answer here…",
        layout=widgets.Layout(width='70%')
    )
    submit_button = widgets.Button(description="Submit", button_style='success')

    def on_submit(b):
        ua = answer_widget.value.strip() or "No answer"
        if q.qtype == "mcq": ua = ua.upper().strip()

        result = evaluate_answer(q, ua)
        qs['answers'].append(ua)
        qs['evals'].append(result)
        qs['history'].append({
            "question":   q.text,
            "user_answer": ua,
            "correct":    result.correct,
            "score":      result.combined,
            "confidence": result.confidence,
            "difficulty": q.difficulty,
            "topic":      q.topic_hint,
        })

        border = "green" if result.correct else "red"
        conf_str = f"  [dim]Confidence: {result.confidence:.0%}[/dim]"
        with _quiz_out:
            console.print(Panel(
                result.feedback + conf_str,
                title=f"Evaluation — Q{i+1} | Score: {result.combined:.0%}",
                border_style=border,
            ))

        qs['current_idx'] += 1
        answer_widget.close()
        submit_button.close()
        _show_next_question()

    submit_button.on_click(on_submit)
    display(answer_widget)
    display(submit_button)

def _finish_quiz():
    global _quiz_state, _quiz_out
    qs    = _quiz_state
    state = qs['state_ref']
    state['user_answers'] = qs['answers']
    state['eval_results'] = qs['evals']
    state['history']      = qs['history']
    with _quiz_out:
        clear_output(wait=True)
        console.print("[bold green]All questions answered. Generating report…[/bold green]")
    updated = tutor_graph.invoke({**state, "command": "report"})
    state.update(updated)
    _quiz_state = _quiz_out = None

HELP_TEXT = """
[bold cyan]Available commands:[/bold cyan]
  [bold]ask <question>[/bold]   Ask anything about the document (RAG)
  [bold]quiz[/bold]             Mixed quiz (MCQ + open-ended), adaptive difficulty
  [bold]quiz mcq[/bold]         MCQ-only quiz
  [bold]quiz open[/bold]        Open-ended quiz
  [bold]report[/bold]           Show session analytics + mastery table
  [bold]mastery[/bold]          Print current topic mastery snapshot
  [bold]help[/bold]             Show this list
  [bold]exit[/bold]             Quit
"""

class AITutor:
    def __init__(self):
        self.vsm     = VectorStoreManager()
        self.state:  Optional[TutorState] = None
        self._loaded = False

    def load(self, path: str):
        try:
            text = load_document(path)
            self.vsm.build(text, source_name=pathlib.Path(path).name)
            self._init_state(text)
            self._loaded = True
            console.print("[bold green]✅ Document indexed.[/bold green]")
        except Exception as e:
            console.print(f"[red]Document loading failed:[/red] {e}")

    def load_from_index(self):
        try:
            self.vsm.load()
            chunks = []
            if self.vsm.vectorstore:
                try: chunks = list(self.vsm.vectorstore.docstore._dict.values())
                except: pass
            self.vsm.chunks = chunks
            self._init_state("")
            self._loaded = True
            console.print("[bold green]✅ FAISS index loaded.[/bold green]")
        except Exception as e:
            console.print(f"[red]Index load failed:[/red] {e}")

    def _init_state(self, text: str):
        self.state = TutorState(
            command="",         document_text=text,
            chunks=self.vsm.chunks, retriever=self.vsm.get_retriever(),
            questions=[],       current_q_idx=0,
            user_answers=[],    eval_results=[],
            session_score=0.0,  weak_topics=[],
            difficulty_level="adaptive",
            history=[],         rag_response="",
            mode="qa",          quiz_mode="mixed",
            last_error="",
            # new fields
            topic_mastery={},   bonus_questions=0,
        )

    def run_command(self, command: str):
        if not self._loaded:
            console.print("[red]Load a document first.[/red]")
            return
        cmd = command.strip()
        if not cmd: return
        if cmd.lower() == "help":
            console.print(HELP_TEXT); return
        if cmd.lower() == "mastery":
            snap = mastery_tracker.summary()
            if not snap:
                console.print("[yellow]No mastery data yet — take a quiz first.[/yellow]")
            else:
                for topic, info in snap.items():
                    console.print(
                        f"[cyan]{topic}[/cyan]: mastery={info['mastery']:.0%} "
                        f"| difficulty={info['difficulty']} "
                        f"| streak={info['streak']} "
                        f"| graduated={'yes' if info['graduated'] else 'no'}"
                    )
            return
        if cmd.lower().startswith("ask "):
            cmd = cmd[4:].strip()
        updated = {**self.state, "command": cmd}
        try:
            self.state = tutor_graph.invoke(updated)
            # If the command was a quiz, start the interactive quiz after questions are generated by the graph
            if cmd.lower().startswith("quiz") and self.state.get("questions"):
                _start_quiz_callback(self.state)
        except Exception as e:
            console.print(f"[red]Error:[/red] {e}")

    def start(self):
        console.print(Panel(
            "[bold cyan]🎓 AI Tutor[/bold cyan]\n\n"
            "RAG · LangGraph · Adaptive Difficulty · Mastery Tracking\n\n"
            "Type [bold]help[/bold] to see commands.",
            border_style="cyan"))
        while True:
            try:
                cmd = input("\n> ").strip()
                if not cmd: continue
                if cmd.lower() in ["exit","quit","q"]:
                    console.print("[bold green]Goodbye 🚀[/bold green]"); break
                self.run_command(cmd)
            except KeyboardInterrupt:
                console.print("\n[yellow]Interrupted.[/yellow]")
            except Exception as e:
                console.print(f"[red]Unexpected error:[/red] {e}")

print("✅ AITutor ready (adaptive difficulty + Qwen feedback + mastery tracking).")