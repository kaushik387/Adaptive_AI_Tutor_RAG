# ─── Imports ─────────────────────────────────────────────────────────────────

import os, re, json, textwrap, warnings, random, pathlib
from typing import List, Dict, Any, Optional, TypedDict
from dataclasses import dataclass, field
from collections import defaultdict

import torch
import numpy as np
import pandas as pd

from tqdm.auto import tqdm

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import print as rprint

from rich.console import Console

console = Console()

# LangChain
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_core.documents import Document

# ❌ REMOVE THESE TWO
# from langchain.chains import RetrievalQA
# from langchain_community.llms import HuggingFacePipeline

# LangGraph
from langgraph.graph import StateGraph, START, END

# HuggingFace Transformers
from transformers import (
    AutoTokenizer,
    AutoModelForSeq2SeqLM,
    AutoModelForCausalLM,
    pipeline,
    T5ForConditionalGeneration,
    T5Tokenizer,
)

from sentence_transformers import SentenceTransformer, util

# Evaluation
from bert_score import score as bert_score_fn

import nltk
nltk.download("punkt", quiet=True)
nltk.download("stopwords", quiet=True)

from nltk.corpus import stopwords

warnings.filterwarnings("ignore")

console = Console()

# ─── Device ────────────────────────────────────────────────────────────────

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

print(f"🖥 Device: {DEVICE}")

# ─── Global Config ─────────────────────────────────────────────────────────

CFG = {
    "embedding_model":      "sentence-transformers/all-MiniLM-L6-v2",
    "qa_model":             "Qwen/Qwen2.5-1.5B-Instruct",
    "qgen_model":           "Qwen/Qwen2.5-1.5B-Instruct",
    "mcq_model":            "Qwen/Qwen2.5-1.5B-Instruct",
    "sim_model":            "sentence-transformers/all-MiniLM-L6-v2",
    "chunk_size":           1200,
    "chunk_overlap":        200,
    "top_k_retrieval":      5,
    "num_questions":        5,
    "faiss_index_path":     "./data/faiss_index",
    "score_threshold":      0.55,
    "mastery_window":       5,
    "mastery_threshold":    0.75,
    "weak_threshold":       0.45,
    "sr_graduate_count":    3,
    "sem_weight":           0.6,
    "kw_weight":            0.4,
    "max_bonus_questions":  3,
}
print("✅ Config loaded.")

from modules.model_hub import ModelHub

models = ModelHub()

