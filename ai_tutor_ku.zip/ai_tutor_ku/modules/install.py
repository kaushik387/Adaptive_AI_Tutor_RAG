import sys
import subprocess

def install(*pkgs):
    subprocess.run(
        [sys.executable, "-m", "pip", "install", "-q", *pkgs],
        check=True
    )

print("Installing core packages...")

# PyTorch
install(
    "torch==2.4.1",
    "torchvision==0.19.1",
    "torchaudio==2.4.1",
    "--index-url",
    "https://download.pytorch.org/whl/cu121"
)

# HF ecosystem
install(
    "transformers==4.44.2",
    "accelerate==0.34.2",
    "sentence-transformers==3.0.1",
    "sentencepiece"
)

# LangChain ecosystem
install(
    "langchain==0.2.16",
    "langchain-core==0.2.38",
    "langchain-community==0.2.16",
    "langchain-huggingface==0.0.3",
    "langsmith==0.1.114"
)

# LangGraph
install(
    "langgraph==0.2.32"
)

# Vector DB
install(
    "faiss-cpu"
)

# Data Science
install(
    "numpy==1.26.4",
    "pandas==2.2.2",
    "scikit-learn==1.2.2",
    "scipy==1.11.4"
)

# NLP & Evaluation
install(
    "nltk",
    "bert-score",
    "rouge-score"
)

# Document Processing
install(
    "pymupdf",
    "python-docx",
    "openpyxl",
    "pytesseract",
    "Pillow"
)

# Utilities
install(
    "ipywidgets",
    "tqdm",
    "rich",
    "groq"
)

print("✅ Installation complete")
print("⚠️ Restart Runtime")