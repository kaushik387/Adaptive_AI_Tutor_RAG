from dataclasses import dataclass
from typing import List, Optional
import re
import random
import json
from sentence_transformers import util
from langchain_core.documents import Document

from modules.config import CFG, console, models, DEVICE

# ─── Question generation ─────────────────────────────────────────────────────

@dataclass
class Question:
    qtype: str            # 'open' | 'mcq'
    text: str             # question text
    options: List[str]    # 4 options for MCQ, empty for open
    correct_answer: str   # reference answer
    context_chunk: str    # source chunk it came from
    topic_hint: str = ""
    difficulty: str = "medium"


# ─── Question quality filters ────────────────────────────────────────────────

def is_good_question(q: str) -> bool:

    q = q.strip()

    if len(q) < 15:
        return False

    if len(q.split()) < 4:
        return False

    bad_patterns = [
        "according to the context",
        "what is mentioned",
        "question:",
        "answer:",
    ]

    q_lower = q.lower()

    if any(p in q_lower for p in bad_patterns):
        return False

    return True


def is_duplicate_question(new_q, existing_questions):

    if not existing_questions:
        return False

    new_emb = models.sim_model.encode(
        new_q,
        convert_to_tensor=True
    )

    old_texts = [
        q.text for q in existing_questions
    ]

    old_embs = models.sim_model.encode(
        old_texts,
        convert_to_tensor=True
    )

    sims = util.cos_sim(
        new_emb,
        old_embs
    )[0]

    return sims.max().item() > 0.85


# ─── Open-ended question generation ─────────────────────────────────────────

def generate_open_questions(
    chunks: List[Document],
    n: int = 5
) -> List[Question]:

    questions = []

    selected = random.sample(
        chunks,
        min(max(n * 5, 10), len(chunks))
    )

    for doc in selected:

        if len(questions) >= n:
            break

        ctx = doc.page_content[:800]

        try:

            messages = [

                {
                    "role": "system",
                    "content":
                    """
You are an expert teacher.

Generate ONE descriptive question.

Rules:
- Ask a conceptual question
- Require explanation
- Output ONLY the question
- No answer
- End with ?
"""
                },

                {
                    "role": "user",
                    "content":
                    f"""
Context:

{ctx}
"""
                }
            ]

            prompt = models.qgen_pipe.tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True
            )

            result = models.qgen_pipe(
                prompt,
                max_new_tokens=64,
                do_sample=True,
                temperature=0.7,
                return_full_text=False
            )

            q_text = result[0]["generated_text"].strip()

            q_text = q_text.replace("\n", " ")

            if "?" in q_text:
                q_text = q_text.split("?")[0] + "?"

            if not q_text.endswith("?"):
                q_text += "?"

            if not is_good_question(q_text):
                continue

            if is_duplicate_question(
                q_text,
                questions
            ):
                continue

            # Generate reference answer

            ref_prompt = f"""
Context:

{ctx}

Question:

{q_text}

Answer:
"""

            ref = models.qa_pipe(
                ref_prompt,
                max_new_tokens=180,
                return_full_text=False
            )[0]["generated_text"].strip()

            if len(ref.split()) < 5:
                continue

            # ── Difficulty estimation ──
            chunk_len = len(ctx.split())

            if chunk_len < 120:
                difficulty = "easy"
            elif chunk_len < 250:
                difficulty = "medium"
            else:
                difficulty = "hard"

            questions.append(

                Question(
                    qtype="open",
                    text=q_text,
                    options=[],
                    correct_answer=ref,
                    context_chunk=ctx,
                    topic_hint=q_text[:50],
                    difficulty=difficulty
                )
            )

        except Exception as e:

            print("Open Question Error:", e)

    console.print(
        f"[green]Generated Open Questions:[/green] "
        f"{len(questions)}/{n}"
    )

    return questions
# ─── MCQ generation using Qwen ──────────────────────────────────────────────

def generate_mcq_qwen(
    chunk_text: str
) -> Optional[Question]:

    try:

        model = models.mcq_pipe["model"]
        tokenizer = models.mcq_pipe["tokenizer"]

        messages = [

            {
                "role": "system",
                "content": (
                    "You are an expert assessment generator.\n"
                    "Create ONE high-quality multiple choice question.\n\n"

                    "Rules:\n"
                    "- Question must test understanding\n"
                    "- 4 realistic options\n"
                    "- Only one correct answer\n"
                    "- Distractors must be plausible\n"
                    "- Avoid obvious wrong choices\n"
                    "- Avoid 'All of the above'\n"
                    "- Avoid 'None of the above'\n"
                    "- Output ONLY valid JSON\n\n"

                    'Format:\n'
                    '{"question":"...","options":["A. ...","B. ...","C. ...","D. ..."],"correct":"A"}'
                )
            },

            {
                "role": "user",
                "content": f"""
Context:
{chunk_text[:700]}
"""
            }
        ]

        text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )

        inputs = tokenizer(
            text,
            return_tensors="pt",
            truncation=True,
            max_length=2048
        ).to(DEVICE)

        outputs = model.generate(
            **inputs,
            max_new_tokens=256,
            temperature=0.7,
            do_sample=True,
            top_p=0.9,
            pad_token_id=tokenizer.eos_token_id
        )

        response = tokenizer.decode(
            outputs[0],
            skip_special_tokens=True
        )

        # ── Extract JSON safely ─────────────────────────

        json_candidates = re.findall(
            r"\{[\s\S]*?\}",
            response
        )

        if not json_candidates:
            return None

        json_text = json_candidates[-1]

        try:
            data = json.loads(json_text)
        except:
            return None

        # ── Validation ─────────────────────────────────

        if "question" not in data:
            return None

        if "options" not in data:
            return None

        if "correct" not in data:
            return None

        if len(data["options"]) != 4:
            return None

        q_text = data["question"].strip()

        if not q_text.endswith("?"):
            q_text += "?"

        if not is_good_question(q_text):
            return None

        unique_options = list(
            dict.fromkeys(data["options"])
        )

        if len(unique_options) != 4:
            return None

        correct_letter = (
            data["correct"]
            .strip()
            .upper()
        )

        correct_option = next(
            (
                opt
                for opt in unique_options
                if opt.upper().startswith(correct_letter)
            ),
            unique_options[0]
        )

        return Question(

            qtype="mcq",

            text=q_text,

            options=unique_options,

            correct_answer=correct_option,

            context_chunk=chunk_text[:300],

            topic_hint=q_text[:60],

            difficulty=random.choice(
                ["easy", "medium", "hard"]
            )
        )

    except Exception as e:

        print(
            f"MCQ generation error: {e}"
        )

        return None

# ─── T5 fallback MCQ generation ─────────────────────────────────────────────

def generate_mcq_t5_fallback(
    chunk_text: str
) -> Optional[Question]:

    try:

        prompt = f"""
Generate ONE conceptual multiple-choice question from the context.

Rules:
- Ask a meaningful educational question
- Output ONLY the question
- Do not provide the answer

Context:
{chunk_text[:500]}

Question:
"""

        q_out = models.qgen_pipe(
            prompt,
            max_new_tokens=64,
            return_full_text=False
        )

        q_text = q_out[0]["generated_text"].strip()

        q_text = q_text.replace("Question:", "").strip()
        q_text = q_text.replace("\n", " ")

        if not q_text.endswith("?"):
            q_text += "?"

        if not is_good_question(q_text):
            return None

        # ── Generate reference answer ───────────────────────────────

        ref_prompt = f"""
Answer using ONLY the context.

Context:
{chunk_text[:400]}

Question:
{q_text}

Answer:
"""

        correct = models.qa_pipe(
            ref_prompt,
            max_new_tokens=80,
        )[0]["generated_text"].strip()

        if len(correct.strip()) < 3:
            return None

        # ── Generate distractors ────────────────────────────────────

        dist_prompt = f"""
Generate 3 plausible but incorrect answers.

Question:
{q_text}

Correct Answer:
{correct}

Rules:
- Same topic/domain
- Similar length
- Different from correct answer
- Output ONLY comma-separated answers
"""

        dist_out = models.qa_pipe(
            dist_prompt,
            max_new_tokens=64,
            return_full_text=False
        )[0]["generated_text"].strip()

        distractors = [
            d.strip()
            for d in dist_out.split(",")
            if d.strip()
        ]

        # Remove duplicates
        distractors = list(dict.fromkeys(distractors))

        # Remove accidental correct-answer duplicates
        distractors = [
            d for d in distractors
            if d.lower() != correct.lower()
        ]

        while len(distractors) < 3:
            distractors.append("Insufficient information")

        distractors = distractors[:3]

        # ── Build options ───────────────────────────────────────────

        options_raw = [correct] + distractors

        random.shuffle(options_raw)

        labels = ["A", "B", "C", "D"]

        options = [
            f"{labels[i]}. {opt}"
            for i, opt in enumerate(options_raw)
        ]

        correct_labeled = next(
            opt
            for opt in options
            if opt[3:] == correct
        )

        return Question(

            qtype="mcq",

            text=q_text,

            options=options,

            correct_answer=correct_labeled,

            context_chunk=chunk_text[:300],

            topic_hint=q_text[:50],

            difficulty=random.choice(
                ["easy", "medium", "hard"]
            ),
        )

    except Exception as e:

        print("Fallback MCQ error:", e)

        return None


# ─── Main question generation entry point ───────────────────────────────────

def generate_questions(

    chunks: List[Document],

    n_open: int = 3,

    n_mcq: int = 2,

    use_qwen: bool = True,

) -> List[Question]:

    console.print(
        f"[cyan]🧠 Generating {n_open} open + "
        f"{n_mcq} MCQ questions ...[/cyan]"
    )

    # ── Generate Open Questions ─────────────────────────────

    open_questions = generate_open_questions(
        chunks,
        n=n_open
    )

    console.print(
        f"[yellow]Open questions generated:[/yellow] "
        f"{len(open_questions)}/{n_open}"
    )

    questions = list(open_questions)

    # ── Generate MCQs ───────────────────────────────────────

    mcq_count = 0

    selected_chunks = random.sample(
        chunks,
        min(max(n_mcq * 5, 15), len(chunks))
    )

    for doc in selected_chunks:

        if mcq_count >= n_mcq:
            break

        q = (

            generate_mcq_qwen(doc.page_content)

            if use_qwen

            else generate_mcq_t5_fallback(doc.page_content)

        )

        if q is None:
            continue

        if is_duplicate_question(
            q.text,
            questions
        ):
            continue

        questions.append(q)

        mcq_count += 1

    # ── Safety Fallback ─────────────────────────────────────

    if len(open_questions) == 0:

        console.print(
            "[red]⚠ No descriptive questions generated.[/red]"
        )

    # ── Shuffle Final Quiz ──────────────────────────────────

    random.shuffle(questions)

    # ── Debug Summary ───────────────────────────────────────

    open_total = sum(
        1 for q in questions
        if q.qtype == "open"
    )

    mcq_total = sum(
        1 for q in questions
        if q.qtype == "mcq"
    )

    console.print(
        f"[green]✓ Quiz Ready:[/green] "
        f"{open_total} OPEN + "
        f"{mcq_total} MCQ"
    )

    return questions


print("✅ Advanced Question Generation ready.")