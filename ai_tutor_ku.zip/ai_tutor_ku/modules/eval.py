from nltk.corpus import stopwords
import nltk
nltk.download('stopwords', quiet=True)
nltk.download("punkt", quiet=True)
nltk.download("punkt_tab", quiet=True)
nltk.download("stopwords", quiet=True)
from nltk.tokenize import word_tokenize
from typing import Dict, List
from dataclasses import dataclass, field
from collections import defaultdict
from sentence_transformers import util

from modules.config import CFG, console, models, DEVICE

STOP = set(stopwords.words("english"))

@dataclass
class EvalResult:
    semantic_score: float
    keyword_score:  float
    combined:       float
    correct:        bool
    feedback:       str
    missed_keywords: List[str]
    confidence:     float = 0.0   # NEW: model-estimated answer confidence

# ── Per-topic mastery tracker (lives for the whole session) ─────────────────
class TopicMasteryTracker:
    """
    Tracks per-topic score history and computes mastery level.
    Used by the adaptive difficulty engine.
    """
    def __init__(self):
        # topic → deque of recent combined scores
        self.history: Dict[str, List[float]] = defaultdict(list)
        # topic → consecutive correct streak
        self.streak:  Dict[str, int]         = defaultdict(int)

    def record(self, topic: str, score: float, correct: bool):
        h = self.history[topic]
        h.append(score)
        # keep only the mastery window
        if len(h) > CFG["mastery_window"]:
            h.pop(0)
        if correct:
            self.streak[topic] += 1
        else:
            self.streak[topic] = 0

    def mastery(self, topic: str) -> float:
        """Weighted average — recent attempts count more."""
        h = self.history[topic]
        if not h:
            return 0.5   # unknown → start at medium
        weights = list(range(1, len(h) + 1))   # linear recency weighting
        return sum(w * s for w, s in zip(weights, h)) / sum(weights)

    def difficulty_for(self, topic: str) -> str:
        m = self.mastery(topic)
        if m >= CFG["mastery_threshold"]:
            return "hard"
        if m <= CFG["weak_threshold"]:
            return "easy"
        return "medium"

    def graduated(self, topic: str) -> bool:
        """
        True when a topic has enough consecutive correct answers.
        """
        return self.streak[topic] >= CFG["sr_graduate_count"]

    def weak_topics(self) -> List[str]:
        return [
            t for t, h in self.history.items()
            if self.mastery(t) <= CFG["weak_threshold"]
        ]

    def summary(self) -> Dict[str, Dict]:
        return {
            t: {
                "mastery": round(self.mastery(t), 3),
                "difficulty": self.difficulty_for(t),
                "streak": self.streak[t],
                "graduated": self.graduated(t),
            }
            for t in self.history
        }

mastery_tracker = TopicMasteryTracker()   # singleton for the session

# ── Helpers ─────────────────────────────────────────────────────────────────
def keyword_overlap(reference: str, hypothesis: str):
    ref_tok = {
        t.lower() for t in word_tokenize(reference)
        if t.isalpha() and t.lower() not in STOP
    }
    hyp_tok = {
        t.lower() for t in word_tokenize(hypothesis)
        if t.isalpha() and t.lower() not in STOP
    }
    if not ref_tok:
        return 1.0, []
    hit = ref_tok & hyp_tok
    missed = list(ref_tok - hyp_tok)
    return len(hit) / len(ref_tok), missed

def _confidence_from_scores(semantic: float, keyword: float) -> float:
    """
    Soft confidence estimate based on agreement between semantic and keyword scores.
    High when both metrics agree; penalised when they diverge sharply.
    """
    agreement_penalty = abs(semantic - keyword)      # 0 = perfect agreement
    raw = CFG["sem_weight"] * semantic + CFG["kw_weight"] * keyword
    return round(max(0.0, raw - 0.15 * agreement_penalty), 4)

# Define generate_qwen_response which was missing
def generate_qwen_response(prompt: str, max_tokens: int = 180) -> str:
    """Helper to get a response from the QA pipeline for feedback."""
    result = models.qa_pipe(prompt, max_new_tokens=max_tokens)
    return result[0]["generated_text"].strip()

# ── Improved feedback via Qwen (reuses the already-loaded QA model) ─────────
def generate_feedback_qwen(
    question:    str,
    reference:   str,
    user_answer: str,
    score:       float,
    missed_keywords: List[str],
    difficulty:  str = "medium",
) -> str:
    missed_text = ", ".join(missed_keywords[:6]) if missed_keywords else "None"
    grade = (
        "Excellent"   if score >= 0.80 else
        "Good"        if score >= 0.65 else
        "Partial"     if score >= 0.45 else
        "Needs work"
    )

    prompt = f"""You are a precise, encouraging AI tutor grading a student's answer.

Question      : {question}
Reference     : {reference}
Student answer: {user_answer}
Score         : {score:.2f} / 1.00  ({grade})
Difficulty    : {difficulty}
Missing terms : {missed_text}

Write a short tutor response (4–6 sentences) covering:
1. One sentence on what the student got right.
2. One sentence on the key gap (if any), referencing the missing terms.
3. One concrete improvement tip or clarifying explanation.
Keep the tone positive and educational. No bullet points, just prose."""

    try:
        response = generate_qwen_response(prompt, max_tokens=180)
        # strip any echoed prompt artifacts
        for marker in ["Student answer:", "Reference:", "Question:", "Write a"]:
            if marker in response:
                response = response.split(marker)[-1]
        return response.strip()
    except Exception as e:
        console.print(f"[yellow]⚠ Feedback generation failed: {e}[/yellow]")
        return f"Score: {score:.0%}. Missing concepts: {missed_text}."

# ── Dynamic threshold per difficulty ────────────────────────────────────────
DIFFICULTY_THRESHOLDS = {"easy": 0.40, "medium": 0.58, "hard": 0.70}

# ── Main evaluation function ─────────────────────────────────────────────────
def evaluate_answer(question, user_answer: str) -> EvalResult:
    ref         = question.correct_answer.strip()
    user_answer = user_answer.strip()
    difficulty  = getattr(question, "difficulty", "medium")
    topic       = getattr(question, "topic_hint", "General")

    # ── MCQ ──────────────────────────────────────────────────────────────────
    if question.qtype == "mcq":
        user_clean     = user_answer.strip().lower()
        correct_letter = question.correct_answer.strip().lower()[0]
        is_correct     = (user_clean == correct_letter or
                          user_clean in question.correct_answer.lower())
        score          = 1.0 if is_correct else 0.0
        feedback       = ("Correct! Well done." if is_correct
                          else f"Incorrect. The right answer is: {question.correct_answer}")
        mastery_tracker.record(topic, score, is_correct)
        return EvalResult(
            semantic_score=score, keyword_score=score, combined=score,
            correct=is_correct, feedback=feedback,
            missed_keywords=[], confidence=score,
        )

    # ── Open-ended ───────────────────────────────────────────────────────────
    if len(user_answer.split()) < 2:
        return EvalResult(0.0, 0.0, 0.0, False,
                          "Answer too short — please elaborate.", [], 0.0)

    # Semantic similarity
    try:
        emb           = models.sim_model.encode([ref, user_answer],
                                                convert_to_tensor=True)
        semantic_score = float(util.cos_sim(emb[0], emb[1]).item())
    except:
        semantic_score = 0.0

    keyword_score, missed = keyword_overlap(ref, user_answer)
    combined   = round(CFG["sem_weight"] * semantic_score +
                       CFG["kw_weight"]  * keyword_score, 4)
    confidence = _confidence_from_scores(semantic_score, keyword_score)
    threshold  = DIFFICULTY_THRESHOLDS.get(difficulty, 0.58)
    is_correct = combined >= threshold

    # Record into mastery tracker
    mastery_tracker.record(topic, combined, is_correct)

    feedback = generate_feedback_qwen(
        question.text, ref, user_answer,
        combined, missed, difficulty,
    )

    return EvalResult(
        semantic_score = round(semantic_score, 4),
        keyword_score  = round(keyword_score,  4),
        combined       = combined,
        correct        = is_correct,
        feedback       = feedback,
        missed_keywords= missed[:5],
        confidence     = confidence,
    )