# ─── Imports ─────────────────────────────────────────────────────────────────

from typing import Dict, List
from langchain_core.documents import Document
from rich.panel import Panel

from modules.config import CFG, console, models, DEVICE

# ─── RAG QA engine ────────────────────────────────────────────────────────────

def build_context(docs: List[Document]) -> str:
    """Concatenate retrieved chunks into a single context string."""
    return "\n\n".join(d.page_content for d in docs)


def rag_answer(query: str, retriever, verbose: bool = False) -> Dict:
    """
    Retrieve relevant chunks, then generate an answer with Flan-T5.
    Returns: {answer, context, sources}
    """
    docs = retriever.invoke(query)
    context = build_context(docs)

    # Flan-T5 prompt format
    prompt = (
        f"Answer the question based on the context below. "
        f"If the answer is a number or formula, include it exactly.\n\n"
        f"Context:\n{context[:1500]}\n\n"
        f"Question: {query}\n\n"
        f"Answer:"
    )

    result = models.qa_pipe(prompt)
    answer = result[0]["generated_text"].strip()

    if verbose:
        console.print(Panel(f"[bold]Q:[/bold] {query}\n[bold]A:[/bold] {answer}", title="RAG Answer"))

    return {
        "answer": answer,
        "context": context,
        "sources": [d.metadata for d in docs],
    }


print("✅ RAG QA engine defined.")