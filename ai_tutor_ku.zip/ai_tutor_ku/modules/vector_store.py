# ─────────────────────────────────────────────────────────────────────────────
# CELL 4 — Production Vector Store Manager
# ─────────────────────────────────────────────────────────────────────────────

from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document

from modules.config import CFG, console, DEVICE

class VectorStoreManager:

    """
    Production-grade FAISS vector manager
    optimized for educational RAG systems.
    """

    def __init__(self):

        # ── Embedding model ───────────────────────────────────────────────

        self.embeddings = HuggingFaceEmbeddings(

            model_name=CFG["embedding_model"],

            model_kwargs={
                "device": DEVICE
            },

            encode_kwargs={
                "normalize_embeddings": True,
                "batch_size": 32
            }
        )

        # ── Text splitter ────────────────────────────────────────────────

        self.splitter = RecursiveCharacterTextSplitter(

            chunk_size=1200,
            chunk_overlap=200,

            separators=[
                "\n\n",
                "\n",
                ". ",
                "! ",
                "? ",
                ";",
                " ",
                ""
            ]
        )

        self.vectorstore = None

        self.chunks = []

    # ─────────────────────────────────────────────────────────────────────

    def remove_duplicate_chunks(self, chunks):

        unique = []

        seen = set()

        for chunk in chunks:

            text = chunk.strip()

            if text not in seen:

                seen.add(text);

                unique.append(text)

        return unique

    # ─────────────────────────────────────────────────────────────────────

    def build(self, text: str, source_name="document"):

        console.print(
            "[cyan]✂ Splitting document into chunks...[/cyan]"
        )

        raw_chunks = self.splitter.split_text(text)

        # Remove duplicates
        raw_chunks = self.remove_duplicate_chunks(raw_chunks)

        self.chunks = []

        for i, chunk in enumerate(raw_chunks):

            metadata = {

                "source": source_name,

                "chunk_id": i,

                "chunk_length": len(chunk),

                "type": "educational_content"
            }

            self.chunks.append(

                Document(
                    page_content=chunk,
                    metadata=metadata
                )
            )

        console.print(
            f"[cyan]🧠 Embedding[/cyan] {len(self.chunks)} chunks..."
        )

        self.vectorstore = FAISS.from_documents(
            self.chunks,
            self.embeddings
        )

        # Save index
        self.vectorstore.save_local(
            CFG["faiss_index_path"]
        )

        console.print(
            f"[green]✓ FAISS index saved:[/green] {CFG['faiss_index_path']}"
        )

    # ─────────────────────────────────────────────────────────────────────

    def load(self):

        self.vectorstore = FAISS.load_local(

            CFG["faiss_index_path"],

            self.embeddings,

            allow_dangerous_deserialization=True
        )

        console.print(
            "[green]✓ FAISS index loaded.[/green]"
        )

    # ─────────────────────────────────────────────────────────────────────

    def get_retriever(self):

        assert self.vectorstore is not None, \
            "Build or load vectorstore first."

        return self.vectorstore.as_retriever(

            search_type="mmr",

            search_kwargs={

                "k": CFG["top_k_retrieval"],

                "fetch_k": 25,

                "lambda_mult": 0.7
            }
        )

    # ─────────────────────────────────────────────────────────────────────

    def retrieve(self, query: str):

        retriever = self.get_retriever()

        docs = retriever.invoke(query)

        # Filter tiny chunks
        docs = [

            d for d in docs

            if len(d.page_content.strip()) > 50
        ]

        return docs

print("✅ Production VectorStoreManager ready.")