import torch

from transformers import (
    pipeline,
    AutoTokenizer,
    AutoModelForCausalLM,
    AutoModelForSeq2SeqLM,
)

from sentence_transformers import SentenceTransformer
from rich.console import Console

console = Console()

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# Import after defining DEVICE
from modules.config import CFG

class ModelHub:

    """
    Central model manager
    """

    def __init__(self):

        self._qa_pipe = None
        self._qgen_pipe = None
        self._mcq_pipe = None
        self._sim_model = None

    # ─────────────────────────────────────────────────────────────────────
    # QA MODEL
    # ─────────────────────────────────────────────────────────────────────

    @property
    def qa_pipe(self):

        if self._qa_pipe is None:

            console.print(
                f"[cyan]⬇ Loading QA model:[/cyan] {CFG['qa_model']}"
            )

            # FLAN-T5
            if "t5" in CFG["qa_model"].lower():

                self._qa_pipe = pipeline(
                    "text2text-generation",
                    model=CFG["qa_model"],
                    tokenizer=CFG["qa_model"],
                    device_map="auto" if DEVICE == "cuda" else None,
                    max_new_tokens=256,
                )

            # Qwen / Llama / Mistral
            else:

                tokenizer = AutoTokenizer.from_pretrained(
                    CFG["qa_model"]
                )

                model = AutoModelForCausalLM.from_pretrained(
                    CFG["qa_model"],
                    torch_dtype=(
                        torch.float16
                        if DEVICE == "cuda"
                        else torch.float32
                    ),
                    device_map="auto",
                )

                self._qa_pipe = pipeline(
                    "text-generation",
                    model=model,
                    tokenizer=tokenizer,
                    max_new_tokens=256,
                )

            console.print(
                "[green]✓ QA model loaded.[/green]"
            )

        return self._qa_pipe

    # ─────────────────────────────────────────────────────────────────────
    # QUESTION GENERATOR
    # ─────────────────────────────────────────────────────────────────────

    @property
    def qgen_pipe(self):

        if self._qgen_pipe is None:

            console.print(
                f"[cyan]⬇ Loading QGen model:[/cyan] "
                f"{CFG['qgen_model']}"
            )

            tokenizer = AutoTokenizer.from_pretrained(
                CFG["qgen_model"]
            )

            model = AutoModelForCausalLM.from_pretrained(
                CFG["qgen_model"],
                torch_dtype=torch.float16 if DEVICE == "cuda" else torch.float32,
                device_map="auto"
            )

            self._qgen_pipe = pipeline(
                "text-generation",
                model=model,
                tokenizer=tokenizer,
                max_new_tokens=64,
                do_sample=True,
                temperature=0.7,
                top_p=0.9
            )

            console.print(
                "[green]✓ Question generator loaded.[/green]"
            )

        return self._qgen_pipe

    # ─────────────────────────────────────────────────────────────────────
    # MCQ MODEL
    # ─────────────────────────────────────────────────────────────────────

    @property
    def mcq_pipe(self):

        if self._mcq_pipe is None:

            console.print(
                f"[cyan]⬇ Loading MCQ model:[/cyan] "
                f"{CFG['mcq_model']}"
            )

            tokenizer = AutoTokenizer.from_pretrained(
                CFG["mcq_model"]
            )

            model = AutoModelForCausalLM.from_pretrained(
                CFG["mcq_model"],
                torch_dtype=(
                    torch.float16
                    if DEVICE == "cuda"
                    else torch.float32
                ),
                device_map="auto",
            )

            self._mcq_pipe = {
                "model": model,
                "tokenizer": tokenizer,
            }

            console.print(
                "[green]✓ MCQ model loaded.[/green]"
            )

        return self._mcq_pipe

    # ─────────────────────────────────────────────────────────────────────
    # SIMILARITY MODEL
    # ─────────────────────────────────────────────────────────────────────

    @property
    def sim_model(self):

        if self._sim_model is None:

            console.print(
                f"[cyan]⬇ Loading similarity model:[/cyan] "
                f"{CFG['sim_model']}"
            )

            self._sim_model = SentenceTransformer(
                CFG["sim_model"],
                device=DEVICE,
            )

            console.print(
                "[green]✓ Similarity model loaded.[/green]"
            )

        return self._sim_model


# ─── Initialise ─────────────────────────────────────────────────────────────

models = ModelHub()

print("✅ ModelHub ready.")