from typing import TypedDict, Any, Dict, List
import numpy as np
from langgraph.graph import StateGraph
from langgraph.constants import START, END
from langchain_core.documents import Document
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from langsmith import traceable

from modules.config import CFG, console, DEVICE, models
from modules.q_gen import Question, generate_questions
from modules.eval import EvalResult, mastery_tracker, evaluate_answer
from modules.rag_engine import rag_answer, build_context

console = Console()

# ─── Tutor State ───────────────────────────────────────────────────────────

class TutorState(TypedDict):

    # user command
    command: str

    # document data
    document_text: str
    chunks: List[Document]
    retriever: Any

    # quiz data
    questions: List[Question]
    current_q_idx: int
    user_answers: List[str]
    eval_results: List[EvalResult]

    # analytics
    session_score: float
    weak_topics: List[str]
    difficulty_level: str
    history: List[Dict]

    # rag
    rag_response: str

    # modes
    mode: str
    quiz_mode: str

    # errors
    last_error: str
    # New fields needed for adaptive learning
    topic_mastery: Dict[str, Any]
    bonus_questions: int


# ─── Difficulty Adaptation ────────────────────────────────────────────────

def get_next_difficulty(results):

    if not results:
        return "medium"

    recent = results[-3:]

    avg = np.mean(
        [r.combined for r in recent]
    )

    if avg >= 0.80:
        return "hard"

    elif avg >= 0.50:
        return "medium"

    return "easy"


# ─── Node: Generate Questions ─────────────────────────────────────────────
@traceable
def node_generate_questions(
    state: TutorState
) -> TutorState:
    try:
        n = CFG["num_questions"]
        cmd = state["command"].lower()
        quiz_mode = "mixed"

        if "mcq" in cmd:
            quiz_mode = "mcq"
        elif "open" in cmd:
            quiz_mode = "open"

        # adaptive difficulty
        difficulty = get_next_difficulty(
            state.get("eval_results", [])
        )

        # determine counts
        if quiz_mode == "mcq":
            n_open = 0
            n_mcq = n
        elif quiz_mode == "open":
            n_open = n
            n_mcq = 0
        else: # mixed
            n_open = max(1, n // 2)
            n_mcq = n - n_open

        console.print(
            f"[cyan]🧠 Quiz Mode:[/cyan] {quiz_mode.upper()} | "
            f"[cyan]Difficulty:[/cyan] {difficulty.upper()} | "
            f"[cyan]Generating[/cyan] {n_open} open + {n_mcq} MCQ questions..."
        )

        # Call the original generate_questions (non-Groq) from Cell 7
        questions = generate_questions(
            chunks=state["chunks"],
            n_open=n_open,
            n_mcq=n_mcq
        )

        return {
            **state,
            "questions": questions,
            "current_q_idx": 0, # Reset for new quiz
            "user_answers": [],
            "eval_results": [],
            "quiz_mode": quiz_mode,
            "difficulty_level": difficulty,
            "last_error": "",
        }

    except Exception as e:
        console.print(
            f"[red]Question Generation Error:[/red] {e}"
        )
        return {
            **state,
            "last_error": str(e),
        }


# ─── Node: RAG Answer ─────────────────────────────────────────────────────

def node_rag_answer(
    state: TutorState
) -> TutorState:

    try:

        # Using the original rag_answer from Cell 6
        result = rag_answer(
            state["command"],
            state["retriever"],
            verbose=True,
        )

        return {

            **state,

            "rag_response": result["answer"],

            "last_error": "",
        }

    except Exception as e:

        console.print(
            f"[red]RAG Error:[/red] {e}"
        )

        return {

            **state,

            "last_error": str(e),
        }



# ─── Node: Session Report ─────────────────────────────────────────────────

def node_report(
    state: TutorState
) -> TutorState:

    results = state["eval_results"]

    if not results:

        console.print(
            "[yellow]No quiz session found.[/yellow]"
        )

        return state

    total = len(results)

    correct = sum(
        1 for r in results
        if r.correct
    )

    avg_score = (
        np.mean(
            [r.combined for r in results]
        ) * 100
    )

    weak_topics = []

    # ── Build Report Table ───────────────────────────────────────────

    table = Table(
        title="📊 Session Report",
        show_lines=True,
    )

    table.add_column(
        "#",
        style="cyan",
        width=5,
    )

    table.add_column(
        "Type",
        style="magenta",
        width=8,
    )

    table.add_column(
        "Score",
        style="yellow",
        width=10,
    )

    table.add_column(
        "Status",
        style="green",
        width=8,
    )

    table.add_column(
        "Question",
        style="white",
        width=50,
    )

    table.add_column(
    "Reference",
    style="cyan",
    width=40,
)

    for i, (q, r) in enumerate(
        zip(state["questions"], results)
    ):

        if not r.correct:

            topic = q.topic_hint

            if not topic:
                topic = q.text[:60]

            weak_topics.append(topic)

        table.add_row(

    str(i + 1),

    q.qtype.upper(),

    f"{r.combined:.0%}",

    "✅" if r.correct else "❌",

    q.text[:60] + "...",

    q.correct_answer[:40]
)

    console.print(table)

    # ── Summary ─────────────────────────────────────────────────────

    console.print(
        f"\n[bold green]Correct:[/bold green] "
        f"{correct}/{total}"
    )

    console.print(
        f"[bold cyan]Average Score:[/bold cyan] "
        f"{avg_score:.1f}%"
    )

    console.print(
        f"[bold magenta]Difficulty:[/bold magenta] "
        f"{state['difficulty_level'].upper()}"
    )

    # ── Weak Topics ─────────────────────────────────────────────────

    if weak_topics:

        console.print(
            "\n[bold red]Topics To Revise:[/bold red]"
        )

        for t in weak_topics:

            console.print(f"• {t}")

    # ── Adaptive Practice Questions ────────────────────────────────
    # This section was using models.qgen_pipe, which is local.
    if weak_topics:

        console.print(
            "\n[bold cyan]Suggested Practice Questions:[/bold cyan]"
        )

        for q, r in zip(
            state["questions"],
            results
        ):

            if not r.correct:

                try:

                    related = state["retriever"].invoke(
                        q.text
                    )

                    # build_context is from cell 6
                    ctx = build_context(
                        related[:2]
                    )

                    practice_prompt = f"""
Generate ONE practice question.

Topic:
{q.text}

Context:
{ctx[:400]}

Question:
"""

                    pq = models.qgen_pipe(
                        practice_prompt,
                        max_new_tokens=64,
                    )[0]["generated_text"].strip()

                    console.print(
                        f"→ {pq}"
                    )

                except Exception:
                    pass

    return {

        **state,

        "session_score": avg_score,

        "weak_topics": weak_topics,
    }


# ─── Error Handler Node ───────────────────────────────────────────────────

def node_error_handler(
    state: TutorState
):

    console.print(
        "[red]⚠ Something went wrong.[/red]"
    )

    if state.get("last_error"):

        console.print(
            f"[yellow]{state['last_error']}[/yellow]"
        )

    return state


# ─── Router ───────────────────────────────────────────────────────────────

def route_command(
    state: TutorState
) -> str:

    if state.get("last_error"):
        return "error_handler"

    cmd = state["command"].lower().strip()

    if cmd.startswith("quiz"):

        return "generate_questions"

    elif cmd.startswith("report"):

        return "report"

    elif cmd.startswith("ask"):

        return "rag_answer"

    return "rag_answer"


# ─── Build LangGraph ──────────────────────────────────────────────────────

def build_tutor_graph():

    g = StateGraph(TutorState)

    # nodes
    g.add_node(
        "route",
        lambda s: s
    )

    g.add_node(
        "rag_answer",
        node_rag_answer
    )

    g.add_node(
        "generate_questions",
        node_generate_questions
    )

    g.add_node(
        "report",
        node_report
    )

    g.add_node(
        "error_handler",
        node_error_handler
    )

    # start
    g.add_edge(
        START,
        "route"
    )

    # routing
    g.add_conditional_edges(

        "route",

        route_command,

        {

            "rag_answer":
                "rag_answer",

            "generate_questions":
                "generate_questions",

            "report":
                "report",

            "error_handler":
                "error_handler",
        }
    )

    # flows

    g.add_edge(
        "rag_answer",
        END
    )

    # IMPORTANT:
    # Cell 10 handles quiz interaction
    g.add_edge(
        "generate_questions",
        END
    )

    g.add_edge(
        "report",
        END
    )

    g.add_edge(
        "error_handler",
        END
    )

    return g.compile()


# ─── Compile Graph ────────────────────────────────────────────────────────

tutor_graph = build_tutor_graph()

print("✅ LangGraph AI Tutor compiled successfully.")