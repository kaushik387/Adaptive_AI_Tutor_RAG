# ─────────────────────────────────────────────────────────────────────────────
# CELL 3 — Production Multi-format Document Loader
# ─────────────────────────────────────────────────────────────────────────────

import fitz
import pathlib
import pandas as pd
import numpy as np

from docx import Document as DocxDocument
from PIL import Image

try:
    import pytesseract
    PYTESSERACT_AVAILABLE = True
except ImportError:
    PYTESSERACT_AVAILABLE = False
    import warnings
    warnings.warn("pytesseract not available - PDF OCR will be skipped. Install Tesseract-OCR from https://github.com/UB-Mannheim/tesseract/wiki")

import re
from modules.config import console

# ─── Text Cleaning ──────────────────────────────────────────────────────────

def clean_text(text: str) -> str:

    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\n{2,}", "\n", text)
    text = text.replace("\x00", " ")

    return text.strip()

# ─── PDF Loader ─────────────────────────────────────────────────────────────

def load_pdf(path: str) -> str:

    doc = fitz.open(path)

    texts = []

    for page_num, page in enumerate(doc):

        text = page.get_text("text")

        # If extracted text too small → OCR fallback
        if len(text.strip()) < 50:

            if PYTESSERACT_AVAILABLE:
                try:
                    pix = page.get_pixmap(dpi=150)

                    img = Image.frombytes(
                        "RGB",
                        [pix.width, pix.height],
                        pix.samples
                    )

                    ocr_text = pytesseract.image_to_string(img)

                    texts.append(ocr_text)
                except Exception as e:
                    console.print(f"[yellow]⚠ OCR failed for page {page_num}: {e}[/yellow]")
                    texts.append(text)
            else:
                texts.append(text)

        else:
            texts.append(text)

    final_text = "\n".join(texts)

    return clean_text(final_text)

# ─── DOCX Loader ────────────────────────────────────────────────────────────

def load_docx(path: str) -> str:

    doc = DocxDocument(path)

    parts = []

    # Paragraphs
    for para in doc.paragraphs:
        if para.text.strip():
            parts.append(para.text)

    # Tables
    for table in doc.tables:
        for row in table.rows:
            row_text = " | ".join(cell.text for cell in row.cells)
            parts.append(row_text)

    return clean_text("\n".join(parts))

# ─── TXT / Markdown Loader ─────────────────────────────────────────────────

def load_txt(path: str) -> str:

    text = pathlib.Path(path).read_text(
        encoding="utf-8",
        errors="replace"
    )

    return clean_text(text)

# ─── CSV / Excel Loader ────────────────────────────────────────────────────

def load_csv_excel(path: str) -> str:

    ext = pathlib.Path(path).suffix.lower()

    if ext == ".csv":
        df = pd.read_csv(path)
    else:
        df = pd.read_excel(path)

    lines = []

    # Dataset overview
    lines.append(f"Dataset contains {df.shape[0]} rows and {df.shape[1]} columns.")

    # Columns
    lines.append(f"Columns: {', '.join(df.columns.astype(str))}")

    # Missing values
    missing = df.isnull().sum()
    missing = missing[missing > 0]

    if len(missing) > 0:
        lines.append("\nMissing Values:")
        lines.append(missing.to_string())

    # Numeric summary
    num_cols = df.select_dtypes(include=np.number).columns

    if len(num_cols) > 0:

        lines.append("\nNumeric Statistics:")
        lines.append(df[num_cols].describe().to_string())

    # Sample rows
    lines.append("\nSample Records:")
    lines.append(df.head(10).to_string(index=False))

    return clean_text("\n".join(lines))

# ─── Image Loader ──────────────────────────────────────────────────────────

def load_image(path: str) -> str:

    img = Image.open(path)

    if PYTESSERACT_AVAILABLE:
        try:
            text = pytesseract.image_to_string(img)
        except Exception as e:
            console.print(f"[yellow]⚠ Image OCR failed: {e}[/yellow]")
            text = f"[Image file: {path}]"
    else:
        text = f"[Image file: {path}]"

    return clean_text(text)

# ─── Supported Loaders ─────────────────────────────────────────────────────

LOADERS = {

    ".pdf": load_pdf,

    ".docx": load_docx,

    ".txt": load_txt,
    ".md": load_txt,

    ".csv": load_csv_excel,
    ".xlsx": load_csv_excel,
    ".xls": load_csv_excel,

    ".png": load_image,
    ".jpg": load_image,
    ".jpeg": load_image,
}

# ─── Main Loader ───────────────────────────────────────────────────────────

def load_document(path: str) -> str:

    ext = pathlib.Path(path).suffix.lower()

    loader = LOADERS.get(ext)

    if loader is None:
        raise ValueError(f"Unsupported file type: {ext}")

    console.print(f"[cyan]📂 Loading:[/cyan] {path}")

    text = loader(path)

    console.print(
        f"[green]✓ Loaded[/green] {len(text):,} characters"
    )

    return text

print("✅ Production document loaders ready.")